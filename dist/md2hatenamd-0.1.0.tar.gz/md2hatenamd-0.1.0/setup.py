# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['md2hatenamd']
entry_points = \
{'console_scripts': ['md2hatenamd = md2hatenamd:main']}

setup_kwargs = {
    'name': 'md2hatenamd',
    'version': '0.1.0',
    'description': 'Convert Markdown to Hatena Blog article written in Markdown mode',
    'long_description': None,
    'author': 'shallovv',
    'author_email': 'miomio.ll.8507@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
